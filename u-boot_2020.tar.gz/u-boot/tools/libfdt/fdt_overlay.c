#include "fdt_host.h"
#include "../scripts/dtc/libfdt/fdt_overlay.c"
