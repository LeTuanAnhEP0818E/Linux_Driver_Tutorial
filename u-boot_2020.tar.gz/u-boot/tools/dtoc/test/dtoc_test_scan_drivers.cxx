/* Aliases must be in driver files */
U_BOOT_DRIVER(sandbox_gpio) {
};

DM_DRIVER_ALIAS(sandbox_gpio, sandbox_gpio_alias2)
